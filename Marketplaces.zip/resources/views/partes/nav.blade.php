<ul class="pc-navbar">
	
	<li class="pc-item">
		<a href="/" class="pc-link "><span class="pc-micon"><i class="fa fa-check"></i></span><span class="pc-mtext">Inicio</span></a>
	</li>
	<li class="pc-item">
		<a href="{{ route('source.item.index') }}" class="pc-link "><span class="pc-micon"><i class="fa fa-check"></i></span><span class="pc-mtext">Listado de items</span></a>
	</li>

	<li class="pc-item">
		<a href="{{ route('source.provider.index') }}" class="pc-link "><span class="pc-micon"><i class="fa fa-check"></i></span><span class="pc-mtext">Proveedores</span></a>
	</li>				
</ul>