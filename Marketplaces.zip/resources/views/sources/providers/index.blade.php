@extends('layouts.base')

@section('content') 
    @if(session('alert_message'))
        <div class="alert alert-{{ session('alert_class') }}" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            {{ session('alert_message') }}
        </div>
    @endif
    
        <div class="row">
              <div class="col-12 offset-0 col-sm-8  col-md-12" >
                <div class="card">
                    <div class="card-header">
                        <h5>Proveedores</h5>
                        <small class="m-0">Listado de proveedores</small>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            @foreach ($data as $key => $d)  
                            <li class="list-group-item d-flex justify-content-between">
                                <p id="{{$d->id}}name" class="m-0 col-8" style="font-size: 1rem; font-weight: 500;">{{ $d->name }}</p>
                                <input id="{{$d->id}}" type="hidden" class="m-0 col-8" style="font-size: 1rem; font-weight: 500;" value="{{ $d->name }}">
                                <input id="{{$d->id}}-Short" type="hidden" class="m-0 col-8" style="font-size: 1rem; font-weight: 500;" value="{{ $d->short_name }}">
                                <div class="col-4 flex-row-reverse d-inline-flex">                               
                                    <button class="btn btn-light" onclick="confirmation({{$d->id}})" data-bs-toggle="modal" data-bs-target="#ConfirmationModal"><i class="fa fa-trash-alt fs-5 px-1"></i></button>                                                                    
                                    <button class="btn btn-light" onclick="formu({{$d->id}})" data-bs-toggle="modal" data-bs-target="#modalMC"><i class="fa fa-edit fs-5 px-1"></i></button>
                                </div>
                            </li>                             
                            @endforeach
                            {{$data -> render()}}
                        </ul>
                    </div>
                </div>
            </div>
        </div>                      

@endsection

@section('search')
    @include('partes.search',['route' => 'source.provider.index'])
@endsection


@section('modal')
    <div class="modal fade" id="modalMC" tabindex="-1" aria-labelledby="modalMC" aria-hidden="true">
      <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalMC">Proveedores</h5> 
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
                <div class="">
                    <div class="row">
                        <div class="col-12 col-sm-8 col-md-6">
                            <div class="row">
                                <div class="col-12" id="fomu">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="ConfirmationModal" tabindex="-1" aria-labelledby="ConfirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ConfirmationModalLabel">¿Desea eliminar este proovedor?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    <a class="btn btn-primary" id="confirm-modal-a">Si</a>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')

@if (count($errors)>0)  
    <script type="text/javascript"> 
        var myModal = new bootstrap.Modal(document.getElementById('modalMC'));
        //myModal.show();
    </script>
    <script> 
    window.onload = function() {
        modald(); 
        myModal.show();
    }
    </script>
@endif

<script>
    var mod = document.getElementById("target-mod");
    mod.setAttribute("onclick", "modald()");
function modald() {
    document.getElementById("fomu").innerHTML=`
    <form action="{{ route('source.provider.create') }}" method="POST">
        @csrf
        <div class="form-group">
            <label class="form-label" >Nombre corto</label>
            <input  class="form-control @error('short_name') is-invalid @enderror" id="short_name" name="short_name" placeholder="Nombre corto" value="{{old('short_name')}}" required>
            @error('short_name')<small id="" class="form-text text-mute ">{{ $message }}</small>@enderror
        </div>
        <div class="form-group">
            <label class="form-label" >Nombre</label>
            <input name="name" class="form-control @error('name') is-invalid @enderror" id="name" placeholder="Nombre" value="{{ old('name') }}" required>
            @error('name')<small id="" class="form-text text-muted">{{ $message }}</small>@enderror
        </div>                                            
        <button type="submit" class="btn  btn-primary">Agregar</button>
    </form>
    `
}

function formu(ide){
    name = document.getElementById(ide).value
    sname = document.getElementById(ide + "-Short").value
    document.getElementById("fomu").innerHTML= `
    <form id="edit-oc" action="update/${ide}" method="POST">
        @method('PUT')
        @csrf
        <div class="form-group">
            <label class="form-label" >Nombre corto</label>
            <input  class="form-control @error('short_name') is-invalid @enderror" id="short_name" name="short_name" value="${sname}" placeholder="Nombre corto" required>
            @error('short_name')<small id="" class="form-text text-mute ">{{ $message }}</small>@enderror
            </div>
            <div class="form-group">
                <label class="form-label" >Nombre</label>
                <input name="name" class="form-control @error('name') is-invalid @enderror" id="name" value="${name}" placeholder="Nombre" required>
                @error('name')<small id="" class="form-text text-muted">{{ $message }}</small>@enderror
                </div>                                            
                <button type="submit" class="btn  btn-primary">Actualizar</button>
                </form>
    `
}

function confirmation(aidi){
    document.getElementById("confirm-modal-a").setAttribute("href", "delete/" + aidi);
}

</script>

<script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
{!! Toastr::message() !!}

@endsection