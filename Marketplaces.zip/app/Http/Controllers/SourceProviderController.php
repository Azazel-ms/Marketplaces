<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SourceProviders;
use App\Models\SourceItems;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;
class SourceProviderController extends Controller
{
    public function __construct()
	{
		
	}

	public function index(Request $request)
	{				
		$data = SourceProviders::Provider($request->search)->paginate(5);		
		$vali = 0;		
		return view("sources.providers.index")->with(['data' => $data, 'vali' => $vali]);
	}	

	public function create(Request $request)
	{
		#validación
		$validate = $this->validate($request,[
            'short_name' => 'required|max:5|min:3',
            'name' => 'required|max:50',
			]
		);

        $list = new SourceProviders($request->all());
		$list -> short_name = $request->short_name;
		$list -> name = $request->name;
		$list -> save();
		$vali = 1;
		\Toastr::success('Registro guardado correctamente','Proveedores');
		return redirect()->route('source.provider.index')->with($vali);
	}


	public function update(Request $request, $id)
	{

		$validate = $this->validate($request,[
            'short_name' => 'required|max:5|min:3',
            'name' => 'required|max:50',
			]
		);

		$pop = SourceProviders::find($id);
		$pop->name = $request->name;
		$pop->short_name = $request->short_name;
		$pop->save();
		$vali = 2;
		return Redirect::back()->with('vali', $vali);		
	}

	public function delete($id)
	{
		if(SourceProviders::find($id) == true){
			SourceProviders::where('id','=',$id)->delete();
			\Toastr::success('Registro eliminado correctamente','Proveedores');
		}else{
			\Toastr::error('El registro no se encuentra en nuestra base de datos','Proveedores');
		};

		return redirect()->route('source.provider.index');
	}
}
