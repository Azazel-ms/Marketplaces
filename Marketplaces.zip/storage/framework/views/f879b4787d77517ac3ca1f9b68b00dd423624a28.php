

<?php $__env->startSection('title'); ?>
Proveedores de items
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<ul>
<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
	<li><?php echo e($li->name); ?></li>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newSourceProvider">
AGREGAR NUEVO
</button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modals'); ?>
<div class="modal fade" id="newSourceProvider" tabindex="-1" aria-labelledby="newSourceProvider" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="newSourceProvider">PROVIDER</h5> 
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        	<div class="">
				<div>									
					<?php if($errors->has): ?>								
						<ul id="errors">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li style="color:red; font-size: 20px;"> <?php echo e($error); ?> </li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					<?php endif; ?>
				</div>
				<form method="post" action="<?php echo e(route('Source_providers_save')); ?>">
					<?php echo csrf_field(); ?>
					<div class="mb-3">
						<label class="form-label">NOMBRE CORTO</label>
						<input class="form-control" name="short_name" required>
					</div>
					<div class="mb-3">
						<label class="form-label">NOMBRE</label>
						<input class="form-control" name="name" required>
					</div>		
					<button type="submit" class="btn btn-primary btn-block">AGREGAR</button>
				</form>
			</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>        
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php if(count($errors)>0): ?>	
	<script type="text/javascript">	
		var myModal = new bootstrap.Modal(document.getElementById('newSourceProvider'));
		myModal.show();
	</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>		


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/sources/source_providers_list.blade.php ENDPATH**/ ?>