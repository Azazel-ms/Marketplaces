<div class="modal fade" id="newSourceProvider" tabindex="-1" aria-labelledby="newSourceProvider" aria-hidden="true">
  <div class="modal-dialog modal-fullscreen">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="newSourceProvider">TITLE</h5> 
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        	<div class="">
				<div>									
					
				</div>
				Cuerpo de modal
			</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/partes/modal.blade.php ENDPATH**/ ?>