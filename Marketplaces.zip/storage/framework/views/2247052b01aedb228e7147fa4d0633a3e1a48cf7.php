<!DOCTYPE html>
<html lang="es">
<head>
    <title>Mercado control</title>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
	<link rel="stylesheet" href="<?php echo e(asset('marketplaces/fonts/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('marketplaces/fonts/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('marketplaces/fonts/material.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('marketplaces/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('marketplaces/css/customizer.css')); ?>">
     <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css"> 
</head>
<body class="">
	<div class="loader-bg">
		<div class="loader-track">
			<div class="loader-fill"></div>
		</div>
	</div>
	<div class="pc-mob-header pc-header">
		<div class="pcm-logo">
			<img src="" alt="" class="logo logo-lg">
		</div>
		<div class="pcm-toolbar">
			<a href="#!" class="pc-head-link" id="mobile-collapse">
				<div class="hamburger hamburger--arrowturn">
					<div class="hamburger-box">
						<div class="hamburger-inner"></div>
					</div>
				</div>				
			</a>
			<a href="#!" class="pc-head-link" id="headerdrp-collapse">
				<i data-feather="align-right"></i>
			</a>
			<a href="#!" class="pc-head-link" id="header-collapse">
				<i data-feather="more-vertical"></i>
			</a>
		</div>
	</div>
	<nav class="pc-sidebar ">
		<div class="navbar-wrapper">
			<div class="m-header">
				<a href="" class="" style="color: white;">
					Mercado control					
				</a>
			</div>
			<div class="navbar-content">
				<?php if(auth()->check()): ?><?php echo $__env->make('partes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
			</div>
		</div>
	</nav>
	
	<header class="pc-header ">
		<div class="header-wrapper">
			<?php if(auth()->check()): ?>
			<div class="ms-auto">
				<ul class="list-unstyled">
					
					<li class="dropdown pc-h-item">
						<a class="pc-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
							<i class="fa fa-search"></i>
						</a>
						<div class="dropdown-menu dropdown-menu-end pc-h-dropdown drp-search">
							<?php echo $__env->yieldContent('search'); ?>
						</div>
					</li>
					<li class="pc-h-item">
						<a class="pc-head-link me-0" href="#" id="target-mod" data-bs-toggle="modal" data-bs-target="#modalMC">
							<i class="fa fa-plus"></i>							
						</a>
					</li>													
					<li class="dropdown pc-h-item">
						<a class="pc-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
							<img src="<?php echo e(asset('marketplaces/images/user/avatar-2.jpg')); ?>" alt="user-image" class="user-avtar">
							<span>
								<span class="user-name"><?php echo e(Auth::user()->name); ?></span>
								<span class="user-desc"><?php echo e(Auth::user()->email); ?></span>
							</span>
						</a>
						<div class="dropdown-menu dropdown-menu-end pc-h-dropdown">
							<div class=" dropdown-header">
								<h5 class="text-overflow m-0"><span class="badge bg-light-success">Pro</span></h5>
							</div>
							<a href="" class="dropdown-item">
								<i class="fa fa-user-circle"></i>
								<span>Profile</span>
							</a>
							<form action="<?php echo e(route('logout')); ?>" method="POST">
								<?php echo csrf_field(); ?>				
										<button type="submit" class="dropdown-item" onclick="event.preventDefault(); this.closest('form').submit();"><i class="fa fa-lock"></i>Cerrar sesión</button>
								</form>
						</div>
					</li>					
				</ul>
			</div>
			<?php endif; ?>
		</div>
	</header>
	
	<?php echo $__env->yieldContent('modal'); ?>
	
	<div class="pc-container">		
	    <div class="pcoded-content">
	    	<?php if(auth()->check()): ?>
	        <div class="row">
	            <div class="col-xl-12 col-md-12">
	                <div class="card feed-card">	                   
	                    <div class="feed-scroll" style="">
	                        <div class="card-body">
	                            <div class="row m-b-25 align-items-center">
	                                <div class="col">	                                    
										<?php echo $__env->yieldContent('content'); ?>	                                        
	                                </div>
	                            </div>                                                       
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php else: ?>
	        MERCADO CONTROL, BIENVENIDOS AQUI DEBE IR EL LANDING PAGE O PARA IR AL <a href="<?php echo e(route('login')); ?>">LOGIN</a>

	    	<?php endif; ?>	    	
	    </div>
	</div>	

    <script src="<?php echo e(asset('marketplaces/js/vendor-all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('marketplaces/js/plugins/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('marketplaces/js/plugins/feather.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('marketplaces/js/pcoded.min.js')); ?>"></script>    	   	
	<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/layouts/base.blade.php ENDPATH**/ ?>