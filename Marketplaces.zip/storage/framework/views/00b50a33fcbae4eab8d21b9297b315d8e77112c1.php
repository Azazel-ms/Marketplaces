

<?php $__env->startSection('title'); ?>
SOURCES ITEMS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="modal-body">
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<div>									
					<?php if($errors->has): ?>								
						<ul id="errors">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li style="color:red; font-size: 20px;"> <?php echo e($error); ?> </li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					<?php endif; ?>
				</div>			
					<div class="mb-3">
						<label class="form-label">BUSCAR EAN</label>
						<input class="form-control" id="ean" required>
					</div>
					<button class="btn btn-primary btn-block" onclick="onJson()">BUSCAR</button>
			</div>
			<div class="col-md-7">
				<samp id="jsonParce" class="text-justify">			
															
				</samp>
			</div>			
		</div>
	</div>	

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>	
function onJson()
{					
	var ean = document.getElementById("ean").value;
	fetch('<?php echo e(asset('')); ?>api/source/'+ean+'/itemsJson')
	  .then(response => response.json())
	  .then(data => {
	  	var jsonParce = document.getElementById('jsonParce')
	  	jsonParce.textContent = JSON.stringify(data.body.data.GeneralInfo)
	  })	 
	  .catch(error => {
	  	console.log(error)
	  });
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/sources/source_items.blade.php ENDPATH**/ ?>