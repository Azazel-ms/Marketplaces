

<li class="dropdown pc-h-item">
	<a class="pc-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
		<i class="material-icons-two-tone">search</i>
	</a>
	<div class="dropdown-menu dropdown-menu-end pc-h-dropdown drp-search">
		<form class="px-3" id="form-search" method="GET" action="<?php echo e(route( $route )); ?>">
			<div class="form-group mb-0 d-flex align-items-center">
				<i data-feather="search"></i>
				<input type="search" class="form-control border-0 shadow-none" placeholder="Search here. . .">
			</div>
		</form>
	</div>
</li><?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/layouts/layout-search.blade.php ENDPATH**/ ?>