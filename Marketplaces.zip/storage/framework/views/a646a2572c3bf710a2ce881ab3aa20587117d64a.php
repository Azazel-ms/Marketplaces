<form class="px-3" id="form-search" method="GET" action="<?php echo e(route( $route )); ?>">
	<div class="form-group mb-0 d-flex align-items-center">
		<i data-feather="search"></i>
		<input type="search" class="form-control border-0 shadow-none" placeholder="Search here. . ." name="search">
	</div>
</form><?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/partes/search.blade.php ENDPATH**/ ?>