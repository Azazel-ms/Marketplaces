

<?php $__env->startSection('content'); ?> 
    <?php if(session('alert_message')): ?>
        <div class="alert alert-<?php echo e(session('alert_class')); ?>" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php echo e(session('alert_message')); ?>

        </div>
    <?php endif; ?>
    
        <div class="row">
              <div class="col-12 offset-0 col-sm-8  col-md-12" >
                <div class="card">
                    <div class="card-header">
                        <h5>Proveedores</h5>
                        <small class="m-0">Listado de proveedores</small>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <li class="list-group-item d-flex justify-content-between">
                                <p id="<?php echo e($d->id); ?>name" class="m-0 col-8" style="font-size: 1rem; font-weight: 500;"><?php echo e($d->name); ?></p>
                                <input id="<?php echo e($d->id); ?>" type="hidden" class="m-0 col-8" style="font-size: 1rem; font-weight: 500;" value="<?php echo e($d->name); ?>">
                                <input id="<?php echo e($d->id); ?>-Short" type="hidden" class="m-0 col-8" style="font-size: 1rem; font-weight: 500;" value="<?php echo e($d->short_name); ?>">
                                <div class="col-4 flex-row-reverse d-inline-flex">                               
                                    <button class="btn btn-light" onclick="confirmation(<?php echo e($d->id); ?>)" data-bs-toggle="modal" data-bs-target="#ConfirmationModal"><i class="fa fa-trash-alt fs-5 px-1"></i></button>                                                                    
                                    <button class="btn btn-light" onclick="formu(<?php echo e($d->id); ?>)" data-bs-toggle="modal" data-bs-target="#modalMC"><i class="fa fa-edit fs-5 px-1"></i></button>
                                </div>
                            </li>                             
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($data -> render()); ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>                      

<?php $__env->stopSection(); ?>

<?php $__env->startSection('search'); ?>
    <?php echo $__env->make('partes.search',['route' => 'source.provider.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="modalMC" tabindex="-1" aria-labelledby="modalMC" aria-hidden="true">
      <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalMC">Proveedores</h5> 
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
                <div class="">
                    <div class="row">
                        <div class="col-12 col-sm-8 col-md-6">
                            <div class="row">
                                <div class="col-12" id="fomu">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="ConfirmationModal" tabindex="-1" aria-labelledby="ConfirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ConfirmationModalLabel">¿Desea eliminar este proovedor?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    <a class="btn btn-primary" id="confirm-modal-a">Si</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php if(count($errors)>0): ?>  
    <script type="text/javascript"> 
        var myModal = new bootstrap.Modal(document.getElementById('modalMC'));
        //myModal.show();
    </script>
    <script> 
    window.onload = function() {
        modald(); 
        myModal.show();
    }
    </script>
<?php endif; ?>

<script>
    var mod = document.getElementById("target-mod");
    mod.setAttribute("onclick", "modald()");
function modald() {
    document.getElementById("fomu").innerHTML=`
    <form action="<?php echo e(route('source.provider.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label class="form-label" >Nombre corto</label>
            <input  class="form-control <?php $__errorArgs = ['short_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="short_name" name="short_name" placeholder="Nombre corto" value="<?php echo e(old('short_name')); ?>" required>
            <?php $__errorArgs = ['short_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small id="" class="form-text text-mute "><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label class="form-label" >Nombre</label>
            <input name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="Nombre" value="<?php echo e(old('name')); ?>" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small id="" class="form-text text-muted"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>                                            
        <button type="submit" class="btn  btn-primary">Agregar</button>
    </form>
    `
}

function formu(ide){
    name = document.getElementById(ide).value
    sname = document.getElementById(ide + "-Short").value
    document.getElementById("fomu").innerHTML= `
    <form id="edit-oc" action="update/${ide}" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label class="form-label" >Nombre corto</label>
            <input  class="form-control <?php $__errorArgs = ['short_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="short_name" name="short_name" value="${sname}" placeholder="Nombre corto" required>
            <?php $__errorArgs = ['short_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small id="" class="form-text text-mute "><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label class="form-label" >Nombre</label>
                <input name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" value="${name}" placeholder="Nombre" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small id="" class="form-text text-muted"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>                                            
                <button type="submit" class="btn  btn-primary">Actualizar</button>
                </form>
    `
}

function confirmation(aidi){
    document.getElementById("confirm-modal-a").setAttribute("href", "delete/" + aidi);
}

</script>

<script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/sources/providers/index.blade.php ENDPATH**/ ?>