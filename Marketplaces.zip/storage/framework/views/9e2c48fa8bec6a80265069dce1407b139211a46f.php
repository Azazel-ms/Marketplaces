

<?php $__env->startSection('title'); ?>
SOURCE PROVIDERS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="">
	<div>ERRORES</div>
	<form method="post" action="<?php echo e(route('Source_providers_save')); ?>">
		<?php echo csrf_field(); ?>
		<div class="mb-3">
			<label for="exampleInputEmail1" class="form-label">NOMBRE CORTO</label>
			<input class="form-control" name="short_name" required>
		</div>
		<div class="mb-3">
			<label for="exampleInputPassword1" class="form-label">NOMBRE</label>
			<input class="form-control" name="name" required>
		</div>		
		<button type="submit" class="btn btn-primary btn-block">AGREGAR</button>
	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\YUGEN TIENDA\Documents\GitHub\Marketplaces\resources\views/sources/source_providers.blade.php ENDPATH**/ ?>